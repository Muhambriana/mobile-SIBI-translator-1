
SIBI_FRCNN_90.10 - v1 90.10
==============================

This dataset was exported via roboflow.ai on May 3, 2021 at 2:24 AM GMT

It includes 520 images.
Sign-language are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 800x800 (Stretch)
* Grayscale (CRT phosphor)

No image augmentation techniques were applied.


